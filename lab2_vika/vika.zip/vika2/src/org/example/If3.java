package org.example;

public interface If3 {  // Наслідується від Interface2
    void meth3();
}