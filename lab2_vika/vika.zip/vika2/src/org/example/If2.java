package org.example;

public interface If2 {  // Наслідується від Interface1
    void meth2();
}
