package org.example;

public class Cl1 extends Cl2 implements If1 {

    Cl1 cl1;

    @Override
    public void meth1() {
        System.out.println("Class1: meth1");
    }

    public void meth2() {
        System.out.println("Class1: meth2");
    }

    public void meth3() {
        System.out.println("Class1: meth3");
    }
}
