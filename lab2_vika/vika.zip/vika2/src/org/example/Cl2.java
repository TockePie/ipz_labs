package org.example;

public class Cl2 implements If2 {

    If1 if1;

    @Override
    public void meth2() {
        System.out.println("Class2: meth2");
    }
}
