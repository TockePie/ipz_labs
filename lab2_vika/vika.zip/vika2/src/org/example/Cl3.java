package org.example;

public class Cl3 implements If3 {

    Cl1 cl1;

    @Override
    public void meth3() {
        System.out.println("Class3: meth3");
    }
}
