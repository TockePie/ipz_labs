package org.example;

public interface If1 extends If2, If3 {
    void meth1();
}
